MICROSOFT HACKATHON PORTFOLIO — Gajula Anushree

Open index.html in Chrome/Edge. No installation is needed.
All visual SVG assets in /assets are original and local, so the page does not depend on external image hosts.

Before submitting:
1. Add your final resume PDF and link it from the page if the rules ask for it.
2. Add real GitHub repository links to each project when available.
3. If your specific Microsoft hackathon requires Microsoft/Azure/Copilot technology, add only the services you actually used and describe the architecture accurately.
4. Do not claim project features or technologies that you did not implement.
